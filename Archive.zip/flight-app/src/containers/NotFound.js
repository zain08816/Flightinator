import React from "react";
import "./NotFound.css";

export default function NotFound() {
    return (
        <div className="NotFound">
            <h3>Whoops... you should be self distancing anyway</h3>
        </div>
    );
}