import React from "react";
import "./Home.css";

export default function Home() {
    return (
        <div className="Home">
            <div className="lander">
                <h1>Flightinator 9000</h1>
                <p>Book A flight here</p>
            </div>
        </div>
    );
}